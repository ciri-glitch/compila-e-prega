import lejos.hardware.motor.Motor;
import lejos.hardware.motor.NXTRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;
import lejos.hardware.Sound;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class RiceviComandi {

    public static void main(String[] args) {
        int port = 12345;
        final NXTRegulatedMotor leftMotor = Motor.B;
        final NXTRegulatedMotor rightMotor = Motor.C;

        final boolean[] running = new boolean[] {true};

        Port portaSensore = SensorPort.S3;
        final EV3UltrasonicSensor ultrasonicSensor = new EV3UltrasonicSensor(portaSensore);
        final SampleProvider distanceProvider = ultrasonicSensor.getDistanceMode();
        final float[] sample = new float[distanceProvider.sampleSize()];

        final double[] position = new double[] {0.0, 0.0}; // x, y in metri
        final long[] lastUpdate = new long[] {System.currentTimeMillis()};
        final int[] currentSpeed = new int[] {0, 0};

        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(port);
            System.out.println("Server in ascolto sulla porta " + port);

            Thread sensorThread = new Thread(new Runnable() {
                public void run() {
                    try {
                        while (running[0]) {
                            distanceProvider.fetchSample(sample, 0);
                            float distanza = sample[0];

                            if (distanza > 0 && distanza < 0.05f) {
                                Sound.beep();
                                Thread.sleep(500);
                            }
                            Thread.sleep(100);
                        }
                    } catch (Exception e) {
                        System.err.println("Errore nel thread sensore: " + e.getMessage());
                    }
                }
            });
            sensorThread.start();

            while (running[0]) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connessione accettata da: " + clientSocket.getInetAddress());

                final Socket client = clientSocket;
                final BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                final PrintWriter out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()), true);

                Thread statusThread = new Thread(new Runnable() {
                    public void run() {
                        try {
                            while (running[0] && !client.isClosed()) {
                                long now = System.currentTimeMillis();

                                double deltaTime = (now - lastUpdate[0]) / 1000.0;
                                lastUpdate[0] = now;

                                double speedM = (currentSpeed[0] + currentSpeed[1]) / 2.0;
                                double speedMS = speedM / 2000.0;

                                position[1] += speedMS * deltaTime;

                                int leftSpeed = leftMotor.getRotationSpeed();
                                int rightSpeed = rightMotor.getRotationSpeed();

                                String speedMsg = "velocita:" + leftSpeed + "," + rightSpeed + "," + now;
                                out.println(speedMsg);

                                String posMsg = String.format("posizione:%.3f,%.3f,%d", position[0], position[1], now);
                                out.println(posMsg);

                                Thread.sleep(500);
                            }
                        } catch (Exception e) {
                            System.err.println("Errore thread stato: " + e.getMessage());
                        }
                    }
                });
                statusThread.start();

                String command;
                while ((command = in.readLine()) != null) {
                    System.out.println("Comando ricevuto: " + command);

                    if (command.startsWith("avanti:")) {
                        int speed = Math.min(Integer.parseInt(command.substring(7)), 1100);
                        currentSpeed[0] = speed;
                        currentSpeed[1] = speed;
                        leftMotor.setSpeed(speed);
                        rightMotor.setSpeed(speed);
                        leftMotor.forward();
                        rightMotor.forward();

                    } else if (command.startsWith("indietro:")) {
                        int speed = Math.min(Integer.parseInt(command.substring(9)), 1100);
                        currentSpeed[0] = -speed;
                        currentSpeed[1] = -speed;
                        leftMotor.setSpeed(speed);
                        rightMotor.setSpeed(speed);
                        leftMotor.backward();
                        rightMotor.backward();

                    } else if (command.startsWith("sinistra:")) {
                        int speed = Math.min(Integer.parseInt(command.substring(9)), 1100);
                        int speedLeft = (int)(speed * 0.5);
                        int speedRight = speed;
                        currentSpeed[0] = speedLeft;
                        currentSpeed[1] = speedRight;
                        leftMotor.setSpeed(speedLeft);
                        rightMotor.setSpeed(speedRight);
                        leftMotor.forward();
                        rightMotor.forward();

                    } else if (command.startsWith("destra:")) {
                        int speed = Math.min(Integer.parseInt(command.substring(7)), 1100);
                        int speedLeft = speed;
                        int speedRight = (int)(speed * 0.5);
                        currentSpeed[0] = speedLeft;
                        currentSpeed[1] = speedRight;
                        leftMotor.setSpeed(speedLeft);
                        rightMotor.setSpeed(speedRight);
                        leftMotor.forward();
                        rightMotor.forward();

                    } else if ("stop".equals(command)) {
                        currentSpeed[0] = 0;
                        currentSpeed[1] = 0;
                        leftMotor.stop(true);
                        rightMotor.stop(true);

                    } else if ("esci".equals(command)) {
                        out.println("Connessione chiusa. Arresto del server.");
                        running[0] = false;
                        break;

                    } else {
                        out.println("Comando non riconosciuto: " + command);
                    }
                }
                client.close();
            }

        } catch (Exception e) {
            System.err.println("Errore nel server: " + e.getMessage());
        } finally {
            try {
                ultrasonicSensor.close();
                if (serverSocket != null) serverSocket.close();
            } catch (Exception e) {
                System.err.println("Errore chiusura: " + e.getMessage());
            }
            System.out.println("Server terminato.");
        }
    }
}
