import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class Interfaccia extends JFrame implements ActionListener {

    private static final String SERVER_ADDRESS = "10.0.1.1";
    private static final int PORT = 12345;

    private PrintWriter out;
    private BufferedReader in;
    private JTextArea logArea;
    private JLabel marciaLabel;
    private JLabel velocitaLabel;
    private JLabel posizioneLabel;

    private int marcia = 1;
    private int[] velocitaMarcia = new int[] {400, 800, 1100};

    private boolean avantiPremuto = false;
    private boolean indietroPremuto = false;
    private boolean sinistraPremuto = false;
    private boolean destraPremuto = false;

    public Interfaccia() {
        try {
            Socket socket = new Socket(SERVER_ADDRESS, PORT);
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            log("Connesso al robot su " + SERVER_ADDRESS + ":" + PORT);

            Thread riceviThread = new Thread(new Runnable() {
                public void run() {
                    try {
                        String line;
                        while ((line = in.readLine()) != null) {
                            if (line.startsWith("velocita:")) {
                                log(">> " + line);
                            } else if (line.startsWith("posizione:")) {
                                aggiornaPosizione(line);
                            } else {
                                log("Ricevuto: " + line);
                            }
                        }
                    } catch (Exception e) {
                        log("Errore ricezione: " + e.getMessage());
                    }
                }
            });
            riceviThread.start();

        } catch (Exception e) {
            log("Errore di connessione: " + e.getMessage());
        }

        setTitle("Controllo Robot EV3");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel controlPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        aggiungiBottone(controlPanel, "Avanti");
        aggiungiBottone(controlPanel, "Indietro");
        aggiungiBottone(controlPanel, "Sinistra");
        aggiungiBottone(controlPanel, "Destra");
        aggiungiBottone(controlPanel, "Stop");
        aggiungiBottone(controlPanel, "Esci");

        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        JPanel infoPanel = new JPanel(new GridLayout(3, 1));
        marciaLabel = new JLabel("Marcia: 1");
        velocitaLabel = new JLabel("Velocità: " + velocitaMarcia[marcia - 1]);
        posizioneLabel = new JLabel("Posizione: x=0.000, y=0.000");

        infoPanel.add(marciaLabel);
        infoPanel.add(velocitaLabel);
        infoPanel.add(posizioneLabel);

        add(controlPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
        add(infoPanel, BorderLayout.NORTH);

        setupKeyBindings();

        setVisible(true);
    }

    private void aggiungiBottone(JPanel panel, String testo) {
        JButton button = new JButton(testo);
        button.setActionCommand(testo.toLowerCase());
        button.addActionListener(this);
        panel.add(button);
    }

    private void log(final String message) {
        System.out.println(message);
        if (logArea != null) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    logArea.append(message + "\n");
                }
            });
        }
    }

    private void inviaComando(String comando) {
        if (out != null) {
            out.println(comando);
            log("Comando inviato: " + comando);
        } else {
            log("ERRORE: Non connesso al robot.");
        }

        if ("esci".equals(comando)) {
            System.exit(0);
        }
    }

    private void aggiornaComando() {
        if (avantiPremuto) {
            if (destraPremuto) {
                inviaComando("destra:" + velocitaMarcia[marcia - 1]);
            } else if (sinistraPremuto) {
                inviaComando("sinistra:" + velocitaMarcia[marcia - 1]);
            } else {
                inviaComando("avanti:" + velocitaMarcia[marcia - 1]);
            }
        } else if (indietroPremuto) {
            inviaComando("indietro:" + velocitaMarcia[marcia - 1]);
        } else {
            inviaComando("stop");
        }
    }

    private void aggiornaPosizione(String line) {
        try {
            String data = line.substring(9);
            String[] parts = data.split(",");
            final double x = Double.parseDouble(parts[0]);
            final double y = Double.parseDouble(parts[1]);
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    posizioneLabel.setText(String.format("Posizione: x=%.3f, y=%.3f", x, y));
                }
            });
        } catch (Exception e) {
            log("Errore parsing posizione: " + e.getMessage());
        }
    }

    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();

        avantiPremuto = false;
        indietroPremuto = false;
        sinistraPremuto = false;
        destraPremuto = false;

        if (comando.equals("avanti") || comando.equals("indietro") ||
            comando.equals("sinistra") || comando.equals("destra")) {
            comando += ":" + velocitaMarcia[marcia - 1];
        }

        inviaComando(comando);

        if (comando.equals("esci")) {
            System.exit(0);
        }
    }

    private void setupKeyBindings() {
        JPanel contentPane = (JPanel) this.getContentPane();

        InputMap im = contentPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = contentPane.getActionMap();

        im.put(KeyStroke.getKeyStroke("W"), "avantiPress");
        im.put(KeyStroke.getKeyStroke("S"), "indietroPress");
        im.put(KeyStroke.getKeyStroke("A"), "sinistraPress");
        im.put(KeyStroke.getKeyStroke("D"), "destraPress");
        im.put(KeyStroke.getKeyStroke("SPACE"), "stop");
        im.put(KeyStroke.getKeyStroke("ESCAPE"), "esci");
        im.put(KeyStroke.getKeyStroke("UP"), "marciaSu");
        im.put(KeyStroke.getKeyStroke("DOWN"), "marciaGiu");

        im.put(KeyStroke.getKeyStroke("released W"), "avantiRelease");
        im.put(KeyStroke.getKeyStroke("released S"), "indietroRelease");
        im.put(KeyStroke.getKeyStroke("released A"), "sinistraRelease");
        im.put(KeyStroke.getKeyStroke("released D"), "destraRelease");

        am.put("avantiPress", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (!avantiPremuto) {
                    avantiPremuto = true;
                    aggiornaComando();
                }
            }
        });
        am.put("indietroPress", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (!indietroPremuto) {
                    indietroPremuto = true;
                    aggiornaComando();
                }
            }
        });
        am.put("sinistraPress", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (!sinistraPremuto) {
                    sinistraPremuto = true;
                    aggiornaComando();
                }
            }
        });
        am.put("destraPress", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (!destraPremuto) {
                    destraPremuto = true;
                    aggiornaComando();
                }
            }
        });

        am.put("stop", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                // 🔧 Modifica: reset anche i flag
                avantiPremuto = false;
                indietroPremuto = false;
                sinistraPremuto = false;
                destraPremuto = false;
                inviaComando("stop");
            }
        });

        am.put("esci", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                inviaComando("esci");
            }
        });

        am.put("marciaSu", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (marcia < 3) {
                    marcia++;
                    aggiornaMarcia();
                    if (avantiPremuto || indietroPremuto || sinistraPremuto || destraPremuto) {
                        aggiornaComando();
                    }
                }
            }
        });
        am.put("marciaGiu", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (marcia > 1) {
                    marcia--;
                    aggiornaMarcia();
                    if (avantiPremuto || indietroPremuto || sinistraPremuto || destraPremuto) {
                        aggiornaComando();
                    }
                }
            }
        });

        am.put("avantiRelease", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                avantiPremuto = false;
                aggiornaComando();
            }
        });
        am.put("indietroRelease", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                indietroPremuto = false;
                aggiornaComando();
            }
        });
        am.put("sinistraRelease", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                sinistraPremuto = false;
                aggiornaComando();
            }
        });
        am.put("destraRelease", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                destraPremuto = false;
                aggiornaComando();
            }
        });
    }

    private void aggiornaMarcia() {
        marciaLabel.setText("Marcia: " + marcia);
        velocitaLabel.setText("Velocità: " + velocitaMarcia[marcia - 1]);
        log("Marcia aggiornata a: " + marcia);
    }

    public static void main(String[] args) {
        new Interfaccia();
    }
}
